package smarttask;

/**
 * Representa una tarea normal.
 */
public class TareaNormal extends Tarea implements Accionable {

    public TareaNormal(int id, String descripcion) {
        super(id, descripcion);
    }

    @Override
    public String obtenerTipo() {
        return "Tarea normal";
    }

    @Override
    public void completar() {
        marcarComoCompletada();
    }
}