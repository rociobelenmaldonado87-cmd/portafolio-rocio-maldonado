package smarttask;

/**
 * Representa una tarea dentro de la aplicación SmartTask.
 */
public abstract class Tarea {

    private int id;
    private String descripcion;
    private boolean completada;

    public Tarea(int id, String descripcion) {
        this.id = id;
        this.descripcion = descripcion;
        this.completada = false;
    }

    public int getId() {
        return id;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public boolean isCompletada() {
        return completada;
    }

    public void marcarComoCompletada() {
        completada = true;
    }

    public abstract String obtenerTipo();

    @Override
    public String toString() {
        String estado;

        if (completada) {
            estado = "Completada";
        } else {
            estado = "Pendiente";
        }

        return id + " - " + descripcion + " - " + obtenerTipo()
                + " - " + estado;
    }
}