package smarttask;

import java.util.Scanner;

/**
 * Clase principal de la aplicación SmartTask.
 */
public class Main {

    public static void main(String[] args) {

        Scanner teclado = new Scanner(System.in);
        GestorTareas gestor = new GestorTareas();

        int opcion = 0;
        int siguienteId = 1;

        System.out.println("Bienvenida a SmartTask");

        do {
            System.out.println("\n--- MENÚ PRINCIPAL ---");
            System.out.println("1. Agregar tarea");
            System.out.println("2. Listar tareas");
            System.out.println("3. Completar tarea");
            System.out.println("4. Eliminar tarea");
            System.out.println("5. Salir");
            System.out.print("Seleccione una opción: ");

            try {
                opcion = Integer.parseInt(teclado.nextLine());

                switch (opcion) {

                case 1:
                    System.out.print("Ingrese la descripción de la tarea: ");
                    String descripcion = teclado.nextLine();

                    System.out.println("Seleccione el tipo de tarea:");
                    System.out.println("1. Tarea normal");
                    System.out.println("2. Tarea urgente");
                    System.out.print("Tipo: ");

                    int tipo = Integer.parseInt(teclado.nextLine());

                    if (tipo == 1) {
                        Tarea tarea = new TareaNormal(
                                siguienteId, descripcion);

                        gestor.agregarTarea(tarea);
                        siguienteId++;

                        System.out.println(
                                "Tarea normal agregada correctamente.");

                    } else if (tipo == 2) {
                        Tarea tarea = new TareaUrgente(
                                siguienteId, descripcion);

                        gestor.agregarTarea(tarea);
                        siguienteId++;

                        System.out.println(
                                "Tarea urgente agregada correctamente.");

                    } else {
                        System.out.println("Tipo de tarea no válido.");
                    }

                    break;

                case 2:
                    gestor.listarTareas();
                    break;

                case 3:
                    System.out.print(
                            "Ingrese el ID de la tarea que desea completar: ");

                    int idCompletar =
                            Integer.parseInt(teclado.nextLine());

                    if (gestor.completarTarea(idCompletar)) {
                        System.out.println(
                                "Tarea marcada como completada.");
                    } else {
                        System.out.println("No se encontró la tarea.");
                    }

                    break;

                case 4:
                    System.out.print(
                            "Ingrese el ID de la tarea que desea eliminar: ");

                    int idEliminar =
                            Integer.parseInt(teclado.nextLine());

                    if (gestor.eliminarTarea(idEliminar)) {
                        System.out.println(
                                "Tarea eliminada correctamente.");
                    } else {
                        System.out.println("No se encontró la tarea.");
                    }

                    break;

                case 5:
                    System.out.println(
                            "Gracias por utilizar SmartTask.");
                    break;

                default:
                    System.out.println(
                            "Opción no válida. Intente nuevamente.");
                }

            } catch (NumberFormatException error) {
                System.out.println(
                        "Debe ingresar solamente números.");
            }

        } while (opcion != 5);

        teclado.close();
    }
}