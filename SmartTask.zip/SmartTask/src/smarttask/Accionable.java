package smarttask;

/**
 * Define la acción que puede realizar una tarea.
 */
public interface Accionable {

    void completar();
}