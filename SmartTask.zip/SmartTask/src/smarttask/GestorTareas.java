package smarttask;

import java.util.ArrayList;
import java.util.List;

/**
 * Administra las tareas de la aplicación SmartTask.
 */
public class GestorTareas {

    private List<Tarea> tareas;

    public GestorTareas() {
        tareas = new ArrayList<>();
    }

    /**
     * Agrega una tarea a la lista.
     */
    public void agregarTarea(Tarea tarea) {
        tareas.add(tarea);
    }

    /**
     * Muestra todas las tareas guardadas.
     */
    public void listarTareas() {
        if (tareas.isEmpty()) {
            System.out.println("No existen tareas registradas.");
        } else {
            System.out.println("\n--- LISTA DE TAREAS ---");

            for (Tarea tarea : tareas) {
                System.out.println(tarea);
            }
        }
    }

    /**
     * Busca una tarea utilizando su identificador.
     */
    public Tarea buscarTarea(int id) {
        for (Tarea tarea : tareas) {
            if (tarea.getId() == id) {
                return tarea;
            }
        }

        return null;
    }

    /**
     * Marca una tarea como completada.
     */
    public boolean completarTarea(int id) {
        Tarea tarea = buscarTarea(id);

        if (tarea != null) {
            ((Accionable) tarea).completar();
            return true;
        }

        return false;
    }

    /**
     * Elimina una tarea utilizando su identificador.
     */
    public boolean eliminarTarea(int id) {
        Tarea tarea = buscarTarea(id);

        if (tarea != null) {
            tareas.remove(tarea);
            return true;
        }

        return false;
    }

    /**
     * Devuelve la lista de tareas.
     */
    public List<Tarea> getTareas() {
        return tareas;
    }
}