package smarttask;

/**
 * Representa una tarea que necesita atención urgente.
 */
public class TareaUrgente extends Tarea implements Accionable {

    public TareaUrgente(int id, String descripcion) {
        super(id, descripcion);
    }

    @Override
    public String obtenerTipo() {
        return "Tarea urgente";
    }

    @Override
    public void completar() {
        marcarComoCompletada();
    }
}