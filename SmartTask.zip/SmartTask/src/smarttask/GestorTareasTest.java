package smarttask;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

/**
 * Pruebas para comprobar el funcionamiento de GestorTareas.
 */
class GestorTareasTest {

    private GestorTareas gestor;

    @BeforeEach
    void prepararPrueba() {
        gestor = new GestorTareas();
    }

    @Test
    void agregarTareaDebeGuardarUnaTarea() {
        Tarea tarea = new TareaNormal(1, "Estudiar Java");

        gestor.agregarTarea(tarea);

        assertEquals(1, gestor.getTareas().size());
    }

    @Test
    void buscarTareaDebeEncontrarlaPorId() {
        Tarea tarea = new TareaUrgente(1, "Entregar evaluación");
        gestor.agregarTarea(tarea);

        Tarea resultado = gestor.buscarTarea(1);

        assertNotNull(resultado);
        assertEquals("Entregar evaluación",
                resultado.getDescripcion());
    }

    @Test
    void completarTareaDebeCambiarSuEstado() {
        Tarea tarea = new TareaNormal(1, "Estudiar");
        gestor.agregarTarea(tarea);

        boolean resultado = gestor.completarTarea(1);

        assertTrue(resultado);
        assertTrue(tarea.isCompletada());
    }

    @Test
    void eliminarTareaDebeQuitarlaDeLaLista() {
        Tarea tarea = new TareaUrgente(1, "Entregar trabajo");
        gestor.agregarTarea(tarea);

        boolean resultado = gestor.eliminarTarea(1);

        assertTrue(resultado);
        assertEquals(0, gestor.getTareas().size());
    }

    @Test
    void buscarIdInexistenteDebeRetornarNull() {
        Tarea resultado = gestor.buscarTarea(99);

        assertNull(resultado);
    }
}